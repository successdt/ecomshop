=== YITH WooCommerce Magnifier ===

Contributors: Your Inspiration Themes
Tags: zoom, magnifier, woocommerce, products, themes, yit, e-commerce, shop
Requires at least: 3.3.1
Tested up to: 3.4.2
Stable tag: 1.0.0

YITH WooCommerce Magnifier 


== Description ==

YITH WooCommerce Magnifier add a zoom effect to product images. Needs WooCommerce to work.


== Suggestions ==

If you have suggestions about how to improve YITH WooCommerce Magnifier, you can [write us](http://yithemes.com "Your Inspiration Themes") so we can bundle them into YITH WooCommerce Magnifier.


== Translators ==

= Available Languages =
* English (Default)
* Italiano

If you have created your own language pack, or have an update for an existing one, you can send [gettext PO and MO file](http://codex.wordpress.org/Translating_WordPress "Translating WordPress")
[use](http://yithemes.com/contact/ "Your Inspiration Themes") so we can bundle it into YITH WooCommerce Languages.


== Installation ==

1. Unzip the downloaded zip file.
2. Upload the `yith_magnifier` folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH WooCommerce Magnifier` from Plugins page


== Configure ==


== Shortcodes ==


== Screenshots ==



== Upgrade notice ==

== Changelog ==

= 1.0.0 =

* Initial release